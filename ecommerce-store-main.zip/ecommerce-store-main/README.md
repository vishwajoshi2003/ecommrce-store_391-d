# E-Commerce Store

Fully responsive fictitious ecommerce website for a dummy company - Hannes & Co.  

Fully functional frontend, would have to integrate with a backend at some point to make it an actual working site where people can place fake orders and what not.  

Users can neither Login nor Register in the account section atm.
